1. ensure that the minim library is installed
2. open the group9_assignment7.pde file
3. click "run"
4. enjoy